
namespace rESTauranter.Models
{
    public abstract class BaseEntity
    {
    }
}