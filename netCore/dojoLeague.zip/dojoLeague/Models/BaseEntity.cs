namespace dojoLeague.Models
{
    public abstract class BaseEntity
    {
    }
}