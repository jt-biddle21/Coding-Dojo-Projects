package com.codingdojo.pokemon;
import java.lang.*;

public class Pokemon {
    private String name;
    private Integer health;
    private String type;
    private static int count;

    public Pokemon(){
        name = "";
        health = 0;
        type = "";
        count++;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Integer getHealth() {

        return health;
    }

    public void setHealth(Integer health) {
        this.health = health;
    }
}
