package com.codingdojo.pokemon;

public class PokemonTest {
    public static void main(String[] args) {
        Pokemon poke1 = new Pokemon("Pikachu", 100, "Electric");
    }
}
