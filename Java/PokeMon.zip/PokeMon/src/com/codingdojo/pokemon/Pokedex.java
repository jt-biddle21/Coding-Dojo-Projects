package com.codingdojo.pokemon;

public class Pokedex extends PokemonAbstract{
    public void pokemonInfo(Pokemon pokemon){

    }
}
