package com.codingdojo.zookeeper1;

public class GorillaTest {
    public static void main(String[] args) throws InterruptedException {
        Gorilla hefe = new Gorilla();
        hefe.throwSomething();
        hefe.throwSomething();
        hefe.throwSomething();
        hefe.eatBananas();
        hefe.eatBananas();
        hefe.climb();
    }
}

