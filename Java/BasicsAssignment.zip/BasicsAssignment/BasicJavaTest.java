public class BasicJavaTest {
    public static void main(String[] args){
        BasicJava test1 = new BasicJava();
        int[] arr = {1, 5, 10, 7, -2};
        test1.shiftArray(arr);
    }
}