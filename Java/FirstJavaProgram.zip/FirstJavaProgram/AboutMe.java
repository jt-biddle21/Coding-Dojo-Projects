public class AboutMe {
    public static void main(String[] args){
        String x = "Justin Biddle";
        int y = 21;
        String z = "Everett";
        System.out.println("My name is " + x + ".");
        System.out.println("I am " + y + " years old.");
        System.out.println("My hometown is " + z + ".");
    }
}