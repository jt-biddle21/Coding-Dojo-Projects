import java.util.Scanner;

public class Pythagorean {
    public static double legA;
    public static double legB;
    public static double hypo;
    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);
        System.out.println("Type in the height length:");
        legA = sc.nextInt();
        System.out.println("Type in the base length:");
        legB = sc.nextInt();
        sc.close();
        hypo = calculateHypotenuse(legA, legB);
        System.out.println(hypo);
    }
    public static double calculateHypotenuse(double legA, double legB)
    {
        double hypotenuse;
        double height = legA * legA;
        double base = legB * legB;
        hypotenuse = Math.sqrt(height + base);
        return hypotenuse;
    }
}
