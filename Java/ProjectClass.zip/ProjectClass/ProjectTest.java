public class ProjectTest{
    public static void main(String[] args){
        Project test1 = new Project("Justin's Project", "Project Description", 500.25);
        System.out.println(test1.elevatorPitch());
    }
}